package com.tutorial.romanconverter.dto;

public class IntegerRequestDTO {
    private int integerValue;

    public int getIntegerValue() {
        return integerValue;
    }

    public void setIntegerValue(int integerValue) {
        this.integerValue = integerValue;
    }
}
